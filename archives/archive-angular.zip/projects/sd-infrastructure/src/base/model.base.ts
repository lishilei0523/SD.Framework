/*模型基类*/
export interface ModelBase {

    /*标识Id*/
    id: string;

    /*编号*/
    number: string;

    /*名称*/
    name: string;

    /*创建时间*/
    addedTime: string;
}
