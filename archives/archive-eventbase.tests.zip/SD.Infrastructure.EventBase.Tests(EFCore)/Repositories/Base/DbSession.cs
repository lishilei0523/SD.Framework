﻿using Microsoft.EntityFrameworkCore;
using SD.Infrastructure.Constants;
using SD.Infrastructure.Repository.EntityFrameworkCore.Base;

namespace SD.Infrastructure.EventBase.Tests.Repositories.Base
{
    /// <summary>
    /// EF上下文
    /// </summary>
    internal class DbSession : DbSessionBase
    {
        /// <summary>
        /// 配置
        /// </summary>
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(NetCoreSetting.WriteConnectionString);
            base.OnConfiguring(optionsBuilder);
        }
    }
}
