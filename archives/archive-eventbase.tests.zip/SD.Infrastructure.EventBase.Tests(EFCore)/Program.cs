﻿using Microsoft.Extensions.DependencyInjection;
using SD.Infrastructure.Constants;
using SD.Infrastructure.EventBase.Tests.Entities;
using SD.Infrastructure.EventBase.Tests.IRepositories;
using SD.Infrastructure.EventBase.Tests.Repositories.Base;
using SD.Infrastructure.Global.Transaction;
using SD.IOC.Core.Mediators;
using SD.IOC.Extension.NetCore;
using System;

namespace SD.Infrastructure.EventBase.Tests
{
    class Program
    {
        static void Main(string[] args)
        {
            if (!ResolveMediator.ContainerBuilt)
            {
                IServiceCollection builder = ResolveMediator.GetServiceCollection();
                builder.RegisterConfigs();

                ResolveMediator.Build();
            }

            DbSession dbSession = new DbSession();
            dbSession.Database.EnsureCreated();

            IUnitOfWorkStub unitOfWork = ResolveMediator.Resolve<IUnitOfWorkStub>();

            GlobalSetting.InitCurrentSessionId();


            Order order = new Order($"SL-{DateTime.Now:yyyyMMddHHmmss}", $"销售订单-{DateTime.Now:yyyyMMddHHmmss}");
            order.Check();

            unitOfWork.RegisterAdd(order);
            unitOfWork.UnitedCommit();

            Console.ReadKey();
        }
    }
}
