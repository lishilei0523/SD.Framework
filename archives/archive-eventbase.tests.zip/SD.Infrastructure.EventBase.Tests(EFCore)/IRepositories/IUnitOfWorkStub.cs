﻿using SD.Infrastructure.RepositoryBase;

namespace SD.Infrastructure.EventBase.Tests.IRepositories
{
    /// <summary>
    /// 单元事务 - Stub
    /// </summary>
    public interface IUnitOfWorkStub : IUnitOfWork
    {

    }
}
