﻿namespace SD.Infrastructure.AppServiceBase
{
    /// <summary>
    /// 应用程序服务基接口
    /// </summary>
    public interface IApplicationService
    {

    }
}
