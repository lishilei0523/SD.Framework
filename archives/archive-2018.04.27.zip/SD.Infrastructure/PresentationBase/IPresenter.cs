﻿namespace SD.Infrastructure.PresentationBase
{
    /// <summary>
    /// 呈现器基接口
    /// </summary>
    public interface IPresenter
    {

    }
}
