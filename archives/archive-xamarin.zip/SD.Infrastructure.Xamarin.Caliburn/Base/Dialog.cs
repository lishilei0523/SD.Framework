﻿using Xamarin.CommunityToolkit.UI.Views;

namespace SD.Infrastructure.Xamarin.Caliburn.Base
{
    /// <summary>
    /// 对话框
    /// </summary>
    public class Dialog : Popup<bool?>
    {

    }
}
