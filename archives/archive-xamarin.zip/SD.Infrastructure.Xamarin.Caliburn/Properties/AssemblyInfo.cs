﻿using Xamarin.Forms;
using Xamarin.Forms.Internals;

//XAML命名空间映射
[assembly: Preserve]
[assembly: XmlnsPrefix("https://github.com/lishilei0523/SD.Framework", "sd")]
[assembly: XmlnsDefinition("https://github.com/lishilei0523/SD.Framework", "SD.Infrastructure.Xamarin.Caliburn.Base")]
