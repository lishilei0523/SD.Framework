﻿using ShSoft.Framework2016.Infrastructure.IRepository;

namespace $safeprojectname$.IRepositories
{
    /// <summary>
    /// 工作单元 - 请自行重命名
    /// </summary>
    public interface IUnitOfWorkConcrete : IUnitOfWork
    {

    }
}
