﻿using System;
using ShSoft.Framework2016.Infrastructure.Global;

namespace $safeprojectname$
{
    /// <summary>
    /// 全局应用程序类
    /// </summary>
    public class Global : HttpApplication
    {
        /// <summary>
        /// 应用程序开始事件
        /// </summary>
        protected void Application_Start(object sender, EventArgs e)
        {
            //初始化数据库
            InitDatabase.Register();
        }
    }
}