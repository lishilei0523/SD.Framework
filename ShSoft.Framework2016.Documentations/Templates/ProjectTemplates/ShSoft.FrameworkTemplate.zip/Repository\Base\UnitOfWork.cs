﻿using ShSoft.Infrastructure.Repository.EntityFramework;
using $safeprojectname$.IRepositories;

namespace $safeprojectname$.Repository.Base
{
    /// <summary>
    /// 单元事务 - 请自行改名
    /// </summary>
    public sealed class UnitOfWork : EFUnitOfWorkProvider, IUnitOfWorkConcrete
    {

    }
}
