﻿using DomainTemp.IRepositories;
using ShSoft.Framework2016.Infrastructure.Repository.EntityFrameworkProvider;

namespace $safeprojectname$.Base
{
    /// <summary>
    /// 单元事务 - 请自行改名
    /// </summary>
    public sealed class UnitOfWork : EFUnitOfWorkProvider, IUnitOfWorkConcrete
    {

    }
}
