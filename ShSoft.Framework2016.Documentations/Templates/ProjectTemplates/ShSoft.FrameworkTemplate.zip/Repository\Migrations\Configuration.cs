using System.Data.Entity.Migrations;
using $safeprojectname$.Base;
using ShSoft.Framework2016.Infrastructure.IRepository;

namespace $safeprojectname$.Migrations
{
    internal sealed class Configuration : DbMigrationsConfiguration<DbSession>
    {
        public Configuration()
        {
            this.AutomaticMigrationsEnabled = true;
            this.AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(DbSession context)
        {
            //��ʼ������
            IDataInitializer initializer = new DataInitializer(context);
            initializer.Initialize();
        }
    }
}
