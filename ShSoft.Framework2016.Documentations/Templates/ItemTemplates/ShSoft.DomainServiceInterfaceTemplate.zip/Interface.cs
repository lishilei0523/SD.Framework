﻿using System;
using ShSoft.Infrastructure.DomainServiceBase;

namespace $rootnamespace$
{
    /// <summary>
    /// XXX领域服务接口
    /// </summary>
	public interface I$safeitemrootname$ : IDomainService<>
	{

	}
}
