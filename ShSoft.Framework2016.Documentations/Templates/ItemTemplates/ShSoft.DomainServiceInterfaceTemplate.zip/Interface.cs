﻿using System;
using ShSoft.Framework2016.Infrastructure.IDomainService;

namespace $rootnamespace$
{
    /// <summary>
    /// XXX领域服务接口
    /// </summary>
	public interface I$safeitemrootname$ : IDomainService<>
	{

	}
}
