﻿using System;
using ShSoft.Framework2016.Common.PoweredByLee;
using ShSoft.Framework2016.Infrastructure.IDomainEvent;

namespace $rootnamespace$
{
    /// <summary>
    /// XXX事件
    /// </summary>
	public class $safeitemrootname$ : DomainEvent
	{
        #region # 构造器

        #region 01.无参构造器
        /// <summary>
        /// 无参构造器
        /// </summary>
        protected $safeitemrootname$() { }
        #endregion

        #region 02.基础构造器


        #endregion

        #endregion

        #region # 属性

        #region 只读属性 - 事件数据 —— $safeitemrootname$Data Data
        /// <summary>
        /// 只读属性 - 事件数据
        /// </summary>
        public $safeitemrootname$Data Data
        {
            get { return base.SourceDataStr.JsonToObject<$safeitemrootname$Data>(); }
        }
        #endregion

        #endregion
	}


    /// <summary>
    /// 事件数据
    /// </summary>
    public struct $safeitemrootname$Data
    {

    }
}
