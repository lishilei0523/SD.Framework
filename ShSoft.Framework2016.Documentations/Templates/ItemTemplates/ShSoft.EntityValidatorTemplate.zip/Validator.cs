﻿using System;
using System.Text;
using FluentValidation;

namespace $rootnamespace$
{
	/// <summary>
	/// XXX实体验证配置
	/// </summary>
	public class $safeitemrootname$ : AbstractValidator<>
	{
		/// <summary>
		/// 构造器
		/// </summary>
		public $safeitemrootname$()
		{
			//在此处写Fluent Validation表达式
		}
	}
}
