﻿using System;
using System.Collections.Generic;
using System.Linq;
using ShSoft.Framework2016.Infrastructure.Repository.EntityFrameworkProvider;

namespace $rootnamespace$
{
    /// <summary>
    /// XXX仓储实现
    /// </summary>
	public class $safeitemrootname$ : EFRepositoryProvider<>, I$safeitemrootname$
	{

	}
}
