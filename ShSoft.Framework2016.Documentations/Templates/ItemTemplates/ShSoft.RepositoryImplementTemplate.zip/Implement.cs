﻿using System;
using System.Collections.Generic;
using System.Linq;
using ShSoft.Infrastructure.Repository.EntityFramework;

namespace $rootnamespace$
{
    /// <summary>
    /// XXX仓储实现
    /// </summary>
	public class $safeitemrootname$ : EFRepositoryProvider<>, I$safeitemrootname$
	{

	}
}
