﻿using System.Runtime.Serialization;

namespace $rootnamespace$
{
    /// <summary>
    /// XXX参数模型
    /// </summary>
    /// <remarks>勿忘[DataMember]</remarks>
    [DataContract(Namespace = "http://$rootnamespace$")]
	public struct $safeitemrootname$
	{
        
	}
}
