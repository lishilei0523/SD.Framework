﻿using System;
using System.Collections.Generic;
using ShSoft.Infrastructure.RepositoryBase;

namespace $rootnamespace$
{
    /// <summary>
    /// XXX仓储接口
    /// </summary>
	public interface $safeitemrootname$ : IRepository<>
	{
   
	}
}
