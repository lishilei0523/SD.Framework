﻿using System;
using System.Collections.Generic;
using ShSoft.Framework2016.Infrastructure.IRepository;

namespace $rootnamespace$
{
    /// <summary>
    /// XXX仓储接口
    /// </summary>
	public interface $safeitemrootname$ : IRepository<>
	{
   
	}
}
